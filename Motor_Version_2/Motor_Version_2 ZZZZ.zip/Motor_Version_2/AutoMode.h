#ifndef AUTOMODE_H
#define AUTOMODE_H

#include <Arduino.h>
#include <NewPing.h>

int detectDistance();

void AutoMode();

#endif