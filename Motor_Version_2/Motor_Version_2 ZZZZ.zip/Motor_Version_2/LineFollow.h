#ifndef LINEFOLLOW_H
#define LINEFOLLOW_H

#include <Arduino.h>

void SlaveMode();

#endif
