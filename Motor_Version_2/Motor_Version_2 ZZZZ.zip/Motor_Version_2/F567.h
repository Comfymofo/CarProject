#ifndef F567_H
#define F567_H

#include <Arduino.h>

int Reading();

#endif
