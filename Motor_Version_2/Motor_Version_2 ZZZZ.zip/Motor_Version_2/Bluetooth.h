#ifndef BLUETOOTH_H
#define BLUETOOTH_H

#include <Arduino.h>

void speed(int x);

void readingstart();

void RemoteMode();

#endif